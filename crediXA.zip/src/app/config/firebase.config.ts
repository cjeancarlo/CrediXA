 export const  firebase = {
    apiKey: "AIzaSyCwVtBAOX54QwlK0PryaLcCEXYqMG1x-nM",
    authDomain: "credixadb.firebaseapp.com",
    databaseURL: "https://credixadb.firebaseio.com",
    projectId: "credixadb",
    storageBucket: "",
    messagingSenderId: "928812661438"
  };