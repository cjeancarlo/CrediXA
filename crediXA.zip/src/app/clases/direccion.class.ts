export class Direccion{
		pais:string;
		ciudad:string;
		calle:string;
		principal:boolean;
}
